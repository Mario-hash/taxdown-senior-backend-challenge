export interface CustomerPersistence {
    _id: string;
    name: string;
    email: string;
    availableCredit: number;
  }
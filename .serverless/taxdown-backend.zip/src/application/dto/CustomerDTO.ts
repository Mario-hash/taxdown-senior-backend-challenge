export interface CustomerDTO {
    id: string;
    name: string;
    email: string;
    availableCredit: number;
  }